package com.rico.weighttracker

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var etWeightGoal: TextView
    private lateinit var etCurrentWeight: TextView
    private lateinit var tvAmountToGoal: TextView
    private lateinit var btCalculateWeight: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        etWeightGoal = findViewById(R.id.etWeightGoal)
        etCurrentWeight = findViewById(R.id.etCurrentWeight)
        tvAmountToGoal = findViewById(R.id.tvAmountToGoal)
        btCalculateWeight = findViewById(R.id.btCalculateWeight)

        btCalculateWeight.setOnClickListener{
            var weight1 = etWeightGoal.text.toString().toInt()
            var weight2 = etCurrentWeight.text.toString().toInt()
            var calcWeight = weight2 - weight1
            tvAmountToGoal.text = "$calcWeight"
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


    }
}